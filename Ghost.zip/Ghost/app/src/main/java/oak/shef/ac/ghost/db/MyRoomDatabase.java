/**
 * Generate an instance of Room Database
 * for further use in app
 */

package oak.shef.ac.ghost.db;


import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import oak.shef.ac.ghost.db.dao.MyDAO;

import static androidx.room.Room.databaseBuilder;


@Entity(tableName = "t_user")
public abstract class MyRoomDatabase extends RoomDatabase {
    public abstract MyDAO myDao();

    private static volatile MyRoomDatabase INSTANCE;



    public static MyRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (MyRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = databaseBuilder(context.getApplicationContext(),
                            MyRoomDatabase.class, "picture_database")
                            // Wipes and rebuilds instead of migrating if no Migration object.
                            // Migration is not part of this codelab.
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            // do any init operation about any initialisation here
        }
    };
}
