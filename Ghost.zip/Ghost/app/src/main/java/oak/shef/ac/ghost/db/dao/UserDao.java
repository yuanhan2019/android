package oak.shef.ac.ghost.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import oak.shef.ac.ghost.db.bean.UserData;

@Dao
public interface UserDao {
    @Query("SELECT * FROM t_user")
    List<UserData> queryAllUserInfo();

    @Query("SELECT * FROM t_user WHERE id = :id")
    UserData getUserById(long id);



    @Insert(onConflict = OnConflictStrategy.REPLACE )
    long[] insertUser(UserData... users);

    @Update
    void updateUser(UserData user);

    @Delete
    void deleteUser(UserData user);


}
