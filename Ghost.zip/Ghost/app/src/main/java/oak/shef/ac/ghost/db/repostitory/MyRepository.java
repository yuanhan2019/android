/**
 * This class is used to interact with database
 */

package oak.shef.ac.ghost.db.repostitory;

import android.app.Application;
import android.os.AsyncTask;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import oak.shef.ac.ghost.db.MyRoomDatabase;
import oak.shef.ac.ghost.db.bean.PictureData;
import oak.shef.ac.ghost.db.dao.MyDAO;


public class MyRepository extends ViewModel {
    private final MyDAO mDBDao;


    public MyRepository(Application application){
        MyRoomDatabase db = MyRoomDatabase.getDatabase(application);
        mDBDao = db.myDao();
    }

    /**
     * Get the instance of database for further use
     * this method will be used in other ViewModel when interaction with database is needed
     * @return the instance of database
     */
    public MyDAO getDB(){
        return mDBDao;

    }



    /**
     * Return a PictureData in LivaData type when database changes
     * @return PictureData in database
     */
    public LiveData<PictureData> getPictureData(){return mDBDao.retrieveOnePicture();}
    //public PictureData getOnePictureData(){return mDBDao.getOnePicture();}
    //public List<PictureData> getAllData(){return mDBDao.getAll();}

    /**
     * Insert a new PictureData to database
     * @param pictureData the data waiting to be inserted into database
     */
    public void insertPicture(PictureData pictureData){
        new insertAsyncTask(mDBDao).execute(pictureData);
    }

    /**
     * A static class used to create an asyncTask to interact with database when be called in View class
     * because we cannot directly interact with database in View
     * The doInBackground method can show a message in Logcat when a PictureData type is
     * inserted into database successfully
     */
    private static class insertAsyncTask extends AsyncTask<PictureData, Void, Void>{
        private MyDAO mAsyncTaskDAo;

        public insertAsyncTask(MyDAO dao){
            mAsyncTaskDAo = dao;
        }

        @Override
        protected Void doInBackground(PictureData... params){
            mAsyncTaskDAo.insert(params[0]);
            Log.i("MyRepository","picture insert: "+params[0].getImage()+"");
            return null;
        }
    }


}
