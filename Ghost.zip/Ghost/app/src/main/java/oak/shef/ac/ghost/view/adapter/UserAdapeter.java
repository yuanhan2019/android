package oak.shef.ac.ghost.view.adapter;

public class UserAdapeter {
}
