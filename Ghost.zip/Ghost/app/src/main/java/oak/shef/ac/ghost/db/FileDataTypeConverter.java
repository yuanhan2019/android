/**
 * Just in order to insert type File in the table of database
 */

package oak.shef.ac.ghost.db;

import androidx.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.lang.reflect.Type;

public class FileDataTypeConverter {
    Gson gson = new Gson();

    @TypeConverter
    public File FileDataToSomeObjectList(String data){
        if(data == null){
            return null;
        }
        Type listType = new TypeToken<File>() {}.getType();

        return gson.fromJson(data, listType);
    }

    @TypeConverter
    public String someObjectListToFile(File someObjects){
        return gson.toJson(someObjects);
    }
}
