/**
 * This class is for displaying the picture to View
 */

package oak.shef.ac.ghost.view.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import oak.shef.ac.ghost.R;
import oak.shef.ac.ghost.db.bean.PictureData;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.View_Holder> {
    static private Context context;
    private static List<PictureData> items;

    public MyAdapter(List<PictureData> items) {
        this.items = items;
    }

    public MyAdapter(Context cont, List<PictureData> items) {
        super();
        this.items = items;
        context = cont;
    }

    /**
     * create view holder and initialize
     * @param parent
     * @param viewType
     * @return
     */
    @Override
    public View_Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        //Inflate the layout, initialize the View Holder
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_image,
                parent, false);
        View_Holder holder = new View_Holder(v);
        context= parent.getContext();
        return holder;
    }

    /**
     * Use the provided View Holder on the onCreateViewHolder method to populate the current row on the RecyclerView
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(final View_Holder holder, final int position) {


        if (holder!=null && items.get(position)!=null) {
            if (items.get(position).getImage()!=-1) {
                holder.imageView.setImageResource(items.get(position).getImage());
            } else if (items.get(position).getFile()!=null){
                Bitmap myBitmap = BitmapFactory.decodeFile(items.get(position).getFile().getAbsolutePath());
                holder.imageView.setImageBitmap(myBitmap);
            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, View_ShowImage.class);
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                }
            });
        }
        //animate(holder);
    }

    /**
     * convenience method for getting data at click position
     * @param id
     * @return
     */
    PictureData getItem(int id) {
        return items.get(id);
    }

    /**
     * Get the size of List of PictureData
     * @return
     */
    @Override
    public int getItemCount() {
        return items.size();
    }

    public class View_Holder extends RecyclerView.ViewHolder  {
        ImageView imageView;


        View_Holder(View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.image_item);

        }


    }

    public static List<PictureData> getItems() {
        return items;
    }

    public static void setItems(List<PictureData> items) {
        MyAdapter.items = items;
    }
}