package oak.shef.ac.ghost.db.bean;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "t_user")
public class UserData {
    @PrimaryKey(autoGenerate = true)
    public long id ;

    @ColumnInfo(name = "user_name")
    public String userName;
    @ColumnInfo(name = "user_password")
    public String userPassword ;

    public UserData(){

    }
    @Ignore
    public UserData(String userName, String userPassword){
        this.userName = userName;
        this.userPassword=userPassword;
    }

    @androidx.annotation.NonNull
    public String getUsername() {
        return userName;
    }
    public void setUserName(@androidx.annotation.NonNull String userName) {
        this.userName = userName;
    }
    public String getUserPassword(){return userPassword;}
    public void setUserPassword(@androidx.annotation.NonNull String userPassword){
        this.userPassword=userPassword;
    }
}
