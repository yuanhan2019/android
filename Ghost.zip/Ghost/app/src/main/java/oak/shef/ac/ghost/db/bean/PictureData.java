/**
 * Define the data structure in RoomDatabase
 * Including the entity structure,
 * Setters and getters for attributions of the defined data
 */

package oak.shef.ac.ghost.db.bean;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.io.File;

import oak.shef.ac.ghost.db.FileDataTypeConverter;

@Entity(tableName = "PictureData")
public class PictureData {
    @PrimaryKey(autoGenerate = true)
    @androidx.annotation.NonNull
    @ColumnInfo(name = "id")
    private int id=0;
    @ColumnInfo(name = "image")
    private int image=-1;
    @ColumnInfo(name = "GPS")
    private String GPS;
    @ColumnInfo(name = "Barametric_pressure")
    private String Barametric_pressure;
    @TypeConverters(FileDataTypeConverter.class)
    private File file = null;

    public PictureData(){

    }
    @Ignore
    public PictureData(int image){this.image = image;}
    @Ignore
    public PictureData(int id, int image, String gps, String bara){
        this.id = id;
        this.image = image;
        this.GPS = gps;
        this.Barametric_pressure = bara;
    }
    @Ignore
    public PictureData(File fileX){this.file=fileX;}

    @androidx.annotation.NonNull

    public int getId() {
        return id;
    }
    public void setId(@androidx.annotation.NonNull int id) {
        this.id = id;
    }
    public String getGPS(){
        return GPS;
    }
    public void setGPS(@androidx.annotation.NonNull String gps){
        this.GPS = gps;
    }
    public String getBarametric_pressure(){
        return Barametric_pressure;
    }
    public void setBarametric_pressure(@androidx.annotation.NonNull String bara){
        this.Barametric_pressure = bara;
    }
    public int getImage(){
        return image;
    }
    public void setImage(@androidx.annotation.NonNull int image) {
        this.image = image;
    }
    public File getFile(){
        return file;
    }
    public void setFile(@androidx.annotation.NonNull File file) {
        this.file = file;
    }


}
