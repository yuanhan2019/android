package oak.shef.ac.ghost.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import oak.shef.ac.ghost.db.bean.PictureData;

@Dao
public interface MyDAO {
    @Insert
    void insertAll(PictureData... pictureData);

    @Insert
    Long insert(PictureData pictureData);

    @Delete
    void delete(PictureData pictureData);



    @Delete
    void deleteAll(PictureData... numberData);

    @Query(("SELECT * FROM PictureData"))
    LiveData<PictureData> retrieveOnePicture();

    @Query(("SELECT * FROM PictureData"))
    PictureData getOnePicture();

    @Query(("SELECT * FROM PictureData"))
    List<PictureData> getAll();
}



