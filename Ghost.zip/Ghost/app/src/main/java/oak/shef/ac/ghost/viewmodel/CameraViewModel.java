package oak.shef.ac.ghost.viewmodel;

import android.app.Activity;
import android.app.Application;
import android.widget.TextView;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

import oak.shef.ac.ghost.R;
import oak.shef.ac.ghost.db.bean.PictureData;
import oak.shef.ac.ghost.db.repostitory.MyRepository;

public class CameraViewModel extends AndroidViewModel {
    private final MyRepository myRepository;
    static LiveData<PictureData> pictureDataToDisplay;
    public static java.util.List<PictureData> myPictureList = new ArrayList<>();
    public static List<PictureData> List = new ArrayList<>();
    private StringBuffer mBuffer;
    private TextView mMsgTV;
    private Activity activity;


    public CameraViewModel (Application application){
        super(application);
        //mBuffer = new StringBuffer();
        myRepository = new MyRepository(application);
        pictureDataToDisplay = myRepository.getPictureData();
        //myRepository.insertPicture(pictureDataToDisplay);

    }

    /**
     * return PictureData to be displayed
     * @return
     */
   public LiveData<PictureData> getPictureDataToDisplay(){
        if(pictureDataToDisplay==null){
            pictureDataToDisplay = new MutableLiveData<PictureData>();
        }
        return pictureDataToDisplay;
    }

    /**
     * insert new PictureData to a list to be displayed
     * @param pictureData
     */
    public void insertToList(PictureData pictureData){
        myPictureList.add(pictureData);
    }

//    public void insertToDatabase(PictureData pictureData){
//        myRepository.insertPicture(pictureData);
//    }


    /**
     * initialize the data when no other action is taken
     */
    public void initData() {
        myRepository.insertPicture(new PictureData(R.drawable.joe1));

        myPictureList.add(new PictureData(R.drawable.joe1));
//        myPictureList.add(new PictureData(R.drawable.joe2));
//        myPictureList.add(new PictureData(R.drawable.joe3));
//        myPictureList.add(new PictureData(R.drawable.joe1));
//        myPictureList.add(new PictureData(R.drawable.joe2));
//        myPictureList.add(new PictureData(R.drawable.joe3));
//        myPictureList.add(new PictureData(R.drawable.joe1));
//        myPictureList.add(new PictureData(R.drawable.joe2));
//        myPictureList.add(new PictureData(R.drawable.joe3));
//        myPictureList.add(new PictureData(R.drawable.joe1));
//        myPictureList.add(new PictureData(R.drawable.joe2));
//        myPictureList.add(new PictureData(R.drawable.joe3));
//        myPictureList.add(new PictureData(R.drawable.joe1));
//        myPictureList.add(new PictureData(R.drawable.joe2));
//        myPictureList.add(new PictureData(R.drawable.joe3));
    }

//    private void setMsg(){
//        runOnUiThread(new Runnable()){
//            @Override
//                    public void run(){
//                String text = mBuffer.toString();
//                mMsgTV.setText(text);
//            }
//
//        }
//    }



}
