package oak.shef.ac.ghost.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import oak.shef.ac.ghost.R;

public class UserListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
